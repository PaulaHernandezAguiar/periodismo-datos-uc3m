# Periodismo de Datos en UC3M

Aquí se podrán encontrar los trabajos y visualizaciones de la alumna **Paula María Hernández Aguiar** durante el curso académico *2021/2022*

## Contenido
- infografias_primer_trabajo
- infografias_segundo_trabajo
- Práctica-4
- img (carpeta de imágenes utilizadas en los trabajos)
- docs 
